
class Chapter17:
    """Real-world Case Studies

    A look at how the Pragmatic Starter Kit has been applied in real-world scenarios.
    """
    def __init__(self):
        self.title = "Real-world Case Studies"
        self.summary = "A look at how the Pragmatic Starter Kit has been applied in real-world scenarios."
    