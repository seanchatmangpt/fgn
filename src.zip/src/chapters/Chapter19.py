
class Chapter19:
    """Contributing to the Project

    How to contribute to the ongoing development and improvement of the Pragmatic Starter Kit.
    """
    def __init__(self):
        self.title = "Contributing to the Project"
        self.summary = "How to contribute to the ongoing development and improvement of the Pragmatic Starter Kit."
    