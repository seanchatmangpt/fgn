
class Chapter16:
    """Customizing the Pragmatic Starter Kit

    Guidelines for customizing and extending the Pragmatic Starter Kit.
    """
    def __init__(self):
        self.title = "Customizing the Pragmatic Starter Kit"
        self.summary = "Guidelines for customizing and extending the Pragmatic Starter Kit."
    